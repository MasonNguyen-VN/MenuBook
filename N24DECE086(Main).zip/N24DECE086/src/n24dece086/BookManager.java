package n24dece086;

import java.util.ArrayList;
import java.util.Comparator;

public class BookManager {
    private ArrayList<Book> danhSach = new ArrayList<>();

    public void themSach(Book b) throws InvalidBookException {
        if (b == null) {
            throw new InvalidBookException("Sach khong duoc null!");
        }

        if (b.getMaSach() == null || b.getMaSach().trim().isEmpty()) {
            throw new InvalidBookException("Ma sach khong duoc de trong!");
        }

        if (timTheoMa(b.getMaSach()) != null) {
            System.out.println("Ma sach da ton tai!");
            return;
        }

        danhSach.add(b);
        System.out.println("Them sach thanh cong!");
    }

    public boolean xoaSach(String maSach) {
        Book b = timTheoMa(maSach);

        if (b == null) {
            System.out.println("Khong tim thay sach!");
            return false;
        }

        danhSach.remove(b);
        System.out.println("Xoa sach thanh cong!");
        return true;
    }

    public Book timTheoMa(String maSach) {
        for (Book b : danhSach) {
            if (b.getMaSach().equalsIgnoreCase(maSach)) {
                return b;
            }
        }

        return null;
    }

    public ArrayList<Book> timTheoTen(String tuKhoa) {
        ArrayList<Book> ketQua = new ArrayList<>();

        if (tuKhoa == null) {
            return ketQua;
        }

        for (Book b : danhSach) {
            if (b.getTenSach().toLowerCase()
                    .contains(tuKhoa.toLowerCase())) {
                ketQua.add(b);
            }
        }

        return ketQua;
    }

    public void inDanhSach() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach sach rong!");
            return;
        }

        for (int i = 0; i < danhSach.size(); i++) {
            System.out.println("\n===== Sach thu " + (i + 1) + " =====");
            System.out.println(danhSach.get(i));
            System.out.println("--------------------");
        }
    }

    public ArrayList<Book> getDanhSach() {
        return danhSach;
    }
    public void sapXepTheoGiaBanTangDan() {
        danhSach.sort(Comparator.comparingDouble(Book::tinhGiaBan));
    }
}