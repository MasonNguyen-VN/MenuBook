package n24dece086;

public class TextBook extends Book {
    private String theLoai;
    private int soTrang;

    public TextBook(String maSach, String tenSach,
                    double giaNhap, int soLuong,
                    String theLoai, int soTrang) {
        super(maSach, tenSach, giaNhap, soLuong);
        this.theLoai = theLoai;
        this.soTrang = soTrang;
    }

    public String getTheLoai() {
        return theLoai;
    }

    public void setTheLoai(String theLoai) {
        this.theLoai = theLoai;
    }

    public int getSoTrang() {
        return soTrang;
    }

    public void setSoTrang(int soTrang) {
        this.soTrang = soTrang;
    }

    @Override
    public double tinhGiaBan() {
        return getGiaNhap() * 1.20;
    }

    @Override
    public String moTa() {
        return "Loai: " + theLoai
                + ", So trang: " + soTrang;
    }

    @Override
    public String toString() {
        return thongTin();
    }
}