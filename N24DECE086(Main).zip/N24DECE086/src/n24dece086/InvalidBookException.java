package n24dece086;

public class InvalidBookException extends Exception {
	// de cap quyen cho class
    private static final long serialVersionUID = 1L;

    public InvalidBookException(String message) {
        super(message);
    }
    // check Exception
    public InvalidBookException(String message, Throwable cause) {
        super(message, cause);
    }
}