package n24dece086;

public class Novel extends Book {
    private String tacGia;
    private int namXuatBan;

    public Novel(String maSach, String tenSach,
                 double giaNhap, int soLuong,
                 String tacGia, int namXuatBan) {
        super(maSach, tenSach, giaNhap, soLuong);
        this.tacGia = tacGia;
        this.namXuatBan = namXuatBan;
    }

    public String getTacGia() {
        return tacGia;
    }

    public void setTacGia(String tacGia) {
        this.tacGia = tacGia;
    }

    public int getNamXuatBan() {
        return namXuatBan;
    }

    public void setNamXuatBan(int namXuatBan) {
        this.namXuatBan = namXuatBan;
    }

    @Override
    public double tinhGiaBan() {
        return getGiaNhap() * 1.30;
    }

    @Override
    public String moTa() {
        return "Tac gia: " + tacGia
                + ", Nam xuat ban: " + namXuatBan;
    }

    @Override
    public String toString() {
        return thongTin();
    }
}