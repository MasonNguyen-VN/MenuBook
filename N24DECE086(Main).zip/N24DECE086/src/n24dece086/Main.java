package n24dece086;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final double PHAN_TRAM_KHUYEN_MAI = 20.0;

    public static void main(String[] args) {
        BookManager quanLy = new BookManager();

        // Khoi tao sach mau
        Book s1 = new TextBook(
                "S001", "Lap trinh Java co ban",
                80000, 50, "Lap trinh", 350
        );

        Book s2 = new Novel(
                "S002", "Dac nhan tam",
                55000, 120, "Dale Carnegie", 1936
        );

        Book s3 = new Magazine(
                "S003", "Tap chi PC World",
                30000, 200, 12, "Hang thang"
        );

        Book s4 = new TextBook(
                "S004", "Giai tich 1",
                65000, 30, "Toan hoc", 280
        );

        Book s5 = new Novel(
                "S005", "Harry Potter (tap 1)",
                120000, 0, "J. K. Rowling", 1997
        );

        // Them sach khuyen mai de kiem tra interface Promotable
        Book s6 = new PromotionalBook(
                "S006", "Lap trinh Java nang cao",
                100000, 20, "Nguyen Van A", 2025,
                PHAN_TRAM_KHUYEN_MAI
        );

        try {
            quanLy.themSach(s1);
            quanLy.themSach(s2);
            quanLy.themSach(s3);
            quanLy.themSach(s4);
            quanLy.themSach(s5);
            quanLy.themSach(s6);

        } catch (InvalidBookException e) {
            System.out.println("Loi khoi tao sach: " + e.getMessage());

        } finally {
            System.out.println("=== Hoan tat khoi tao ===");
        }

        int luaChon;

        do {
            hienThiMenu();
            luaChon = nhapSoNguyen("Chon chuc nang: ");

            try {
                switch (luaChon) {
                    case 1:
                        themSachGiaoKhoa(quanLy);
                        break;

                    case 2:
                        themTieuThuyet(quanLy);
                        break;

                    case 3:
                        themTapChi(quanLy);
                        break;

                    case 4:
                        inBangSach(quanLy);
                        break;

                    case 5:
                        timKiemSach(quanLy);
                        break;

                    case 6:
                        xoaSach(quanLy);
                        break;

                    case 7:
                        quanLy.sapXepTheoGiaBanTangDan();
                        System.out.println(
                                "Da sap xep sach theo gia ban tang dan."
                        );
                        inBangSach(quanLy);
                        break;

                    case 8:
                        apDungKhuyenMai(quanLy);
                        break;

                    case 9:
                        hienThiThongTinDaHinh(quanLy);
                        thongKeKhuyenMaiVaDoanhThu(quanLy);
                        break;

                    case 10:
                        kiemThuNgoaiLe(quanLy);
                        break;

                    case 0:
                        System.out.println("Ket thuc chuong trinh!");
                        break;

                    default:
                        System.out.println(
                                "Lua chon khong hop le. Vui long chon tu 0 den 10."
                        );
                }

            } catch (InvalidBookException e) {
                System.out.println("Loi: " + e.getMessage());
            }

        } while (luaChon != 0);
    }

    // Hien thi menu
    public static void hienThiMenu() {
        System.out.println("\n==============================================");
        System.out.println("          QUAN LY CUA HANG SACH");
        System.out.println("==============================================");
        System.out.println("1. Them sach giao khoa");
        System.out.println("2. Them tieu thuyet");
        System.out.println("3. Them tap chi");
        System.out.println("4. Hien thi danh sach sach");
        System.out.println("5. Tim kiem sach");
        System.out.println("6. Xoa sach");
        System.out.println("7. Sap xep theo gia ban tang dan");
        System.out.println("8. Ap dung khuyen mai 20% cho tat ca sach");
        System.out.println("9. Hien thi da hinh va thong ke");
        System.out.println("10. Kiem thu cac truong hop ngoai le");
        System.out.println("0. Thoat");
        System.out.println("==============================================");
    }

    // Nhap chuoi
    public static String nhapChuoi(String thongBao) {
        System.out.print(thongBao);
        return sc.nextLine().trim();
    }

    // Nhap so nguyen
    public static int nhapSoNguyen(String thongBao) {
        while (true) {
            System.out.print(thongBao);

            try {
                return Integer.parseInt(sc.nextLine().trim());

            } catch (NumberFormatException e) {
                System.out.println(
                        "Vui long nhap mot so nguyen hop le!"
                );
            }
        }
    }

    // Nhap so thuc
    public static double nhapSoThuc(String thongBao) {
        while (true) {
            System.out.print(thongBao);

            try {
                double giaTri = Double.parseDouble(
                        sc.nextLine().trim()
                );

                if (Double.isNaN(giaTri)
                        || Double.isInfinite(giaTri)) {
                    System.out.println("Gia tri khong hop le!");
                    continue;
                }

                return giaTri;

            } catch (NumberFormatException e) {
                System.out.println(
                        "Vui long nhap mot so thuc hop le!"
                );
            }
        }
    }

    // Nhap ma sach
    public static String nhapMaSach() {
        while (true) {
            String ma = nhapChuoi("Nhap ma sach: ");

            if (!ma.isEmpty()) {
                return ma;
            }

            System.out.println("Ma sach khong duoc de trong!");
        }
    }

    // Nhap ten sach
    public static String nhapTenSach() {
        while (true) {
            String ten = nhapChuoi("Nhap ten sach: ");

            if (!ten.isEmpty()) {
                return ten;
            }

            System.out.println("Ten sach khong duoc de trong!");
        }
    }

    // Nhap gia nhap
    public static double nhapGiaNhap() {
        while (true) {
            double gia = nhapSoThuc("Nhap gia nhap: ");

            if (gia >= 0) {
                return gia;
            }

            System.out.println("Gia nhap khong duoc am!");
        }
    }

    // Nhap so luong
    public static int nhapSoLuong() {
        while (true) {
            int soLuong = nhapSoNguyen("Nhap so luong: ");

            if (soLuong >= 0) {
                return soLuong;
            }

            System.out.println("So luong khong duoc am!");
        }
    }

    // Them sach giao khoa
    public static void themSachGiaoKhoa(BookManager quanLy)
            throws InvalidBookException {

        System.out.println("\n===== THEM SACH GIAO KHOA =====");

        String ma = nhapMaSach();
        String ten = nhapTenSach();
        double gia = nhapGiaNhap();
        int soLuong = nhapSoLuong();
        String theLoai = nhapChuoi("Nhap the loai: ");
        int soTrang = nhapSoNguyen("Nhap so trang: ");

        if (soTrang <= 0) {
            System.out.println("So trang phai lon hon 0!");
            return;
        }

        TextBook sach = new TextBook(
                ma, ten, gia, soLuong, theLoai, soTrang
        );

        quanLy.themSach(sach);
    }

    // Them tieu thuyet
    public static void themTieuThuyet(BookManager quanLy)
            throws InvalidBookException {

        System.out.println("\n===== THEM TIEU THUYET =====");

        String ma = nhapMaSach();
        String ten = nhapTenSach();
        double gia = nhapGiaNhap();
        int soLuong = nhapSoLuong();
        String tacGia = nhapChuoi("Nhap tac gia: ");
        int nam = nhapSoNguyen("Nhap nam xuat ban: ");

        if (nam <= 0) {
            System.out.println("Nam xuat ban phai lon hon 0!");
            return;
        }

        Novel sach = new Novel(
                ma, ten, gia, soLuong, tacGia, nam
        );

        quanLy.themSach(sach);
    }

    // Them tap chi
    public static void themTapChi(BookManager quanLy)
            throws InvalidBookException {

        System.out.println("\n===== THEM TAP CHI =====");

        String ma = nhapMaSach();
        String ten = nhapTenSach();
        double gia = nhapGiaNhap();
        int soLuong = nhapSoLuong();
        int soKy = nhapSoNguyen("Nhap so ky: ");
        String tanSuat = nhapChuoi(
                "Nhap tan suat xuat ban: "
        );

        if (soKy <= 0) {
            System.out.println("So ky phai lon hon 0!");
            return;
        }

        Magazine sach = new Magazine(
                ma, ten, gia, soLuong, soKy, tanSuat
        );

        quanLy.themSach(sach);
    }

    // Hien thi danh sach sach
    public static void inBangSach(BookManager quanLy) {
        ArrayList<Book> danhSach = quanLy.getDanhSach();

        System.out.println(
                "\n======================= DANH SACH SACH ======================="
        );

        if (danhSach.isEmpty()) {
            System.out.println("Danh sach sach rong!");
            return;
        }

        System.out.printf(
                "%-8s | %-26s | %-12s | %12s | %8s | %12s%n",
                "Ma sach", "Ten sach", "Loai sach",
                "Gia nhap", "So luong", "Gia ban"
        );

        System.out.println(
                "---------+----------------------------+--------------+--------------+----------+--------------"
        );

        for (Book b : danhSach) {
            String loai;

            if (b instanceof PromotionalBook) {
                loai = "Khuyen mai";

            } else if (b instanceof TextBook) {
                loai = "Giao khoa";

            } else if (b instanceof Novel) {
                loai = "Tieu thuyet";

            } else if (b instanceof Magazine) {
                loai = "Tap chi";

            } else {
                loai = "Khac";
            }

            System.out.printf(
                    "%-8s | %-26.26s | %-12s | %12.0f | %8d | %12.0f%n",
                    b.getMaSach(),
                    b.getTenSach(),
                    loai,
                    b.getGiaNhap(),
                    b.getSoLuong(),
                    b.tinhGiaBan()
            );
        }

        System.out.println(
                "======================================================================"
        );
    }

    // Tim sach theo ma hoac ten
    public static void timKiemSach(BookManager quanLy) {
        System.out.println("\n===== TIM KIEM SACH =====");
        System.out.println("1. Tim theo ma sach");
        System.out.println("2. Tim theo ten sach");

        int luaChon;

        do {
            luaChon = nhapSoNguyen(
                    "Chon cach tim kiem (1 hoac 2): "
            );

            if (luaChon != 1 && luaChon != 2) {
                System.out.println(
                        "Lua chon khong hop le. Vui long nhap 1 hoac 2."
                );
            }

        } while (luaChon != 1 && luaChon != 2);

        if (luaChon == 1) {
            String ma = nhapChuoi(
                    "Nhap ma sach can tim: "
            );

            Book sach = quanLy.timTheoMa(ma);

            if (sach != null) {
                System.out.println("\nThong tin sach tim duoc:");
                System.out.println(sach);

            } else {
                System.out.println(
                        "Khong tim thay sach co ma " + ma + "!"
                );
            }

        } else {
            String tuKhoa = nhapChuoi(
                    "Nhap tu khoa ten sach: "
            );

            ArrayList<Book> ketQua =
                    quanLy.timTheoTen(tuKhoa);

            if (ketQua.isEmpty()) {
                System.out.println(
                        "Khong tim thay sach phu hop voi tu khoa: "
                                + tuKhoa
                );

            } else {
                System.out.println("\nKet qua tim kiem:");

                for (Book b : ketQua) {
                    System.out.println(b);
                    System.out.println(
                            "-----------------------------------"
                    );
                }
            }
        }
    }

    // Xoa sach
    public static void xoaSach(BookManager quanLy) {
        String ma = nhapChuoi(
                "\nNhap ma sach can xoa: "
        );

        quanLy.xoaSach(ma);
    }

    // Ap dung khuyen mai 20%
    public static void apDungKhuyenMai(BookManager quanLy) {
        ArrayList<Book> danhSach = quanLy.getDanhSach();

        System.out.println(
                "\n===== AP DUNG KHUYEN MAI 20% ====="
        );

        if (danhSach.isEmpty()) {
            System.out.println("Danh sach sach rong!");
            return;
        }

        System.out.printf(
                "%-8s | %-26s | %12s | %16s%n",
                "Ma sach", "Ten sach",
                "Gia goc", "Gia sau khuyen mai"
        );

        System.out.println(
                "---------+----------------------------+--------------+------------------"
        );

        for (Book b : danhSach) {
            double giaGoc = b.tinhGiaBan();
            double giaKhuyenMai;

            if (b instanceof Promotable) {
                PromotionalBook pb = (PromotionalBook) b;

                pb.setMucKhuyenMai(
                        PHAN_TRAM_KHUYEN_MAI
                );

                giaKhuyenMai = pb.apDungKhuyenMai(
                        PHAN_TRAM_KHUYEN_MAI
                );

            } else {
                giaKhuyenMai = giaGoc
                        * (1 - PHAN_TRAM_KHUYEN_MAI / 100.0);
            }

            System.out.printf(
                    "%-8s | %-26.26s | %12.0f | %16.0f%n",
                    b.getMaSach(),
                    b.getTenSach(),
                    giaGoc,
                    giaKhuyenMai
            );
        }

        System.out.println(
                "Gia ban goc khong bi thay doi."
        );
    }

    // Minh hoa tinh da hinh
    public static void hienThiThongTinDaHinh(
            BookManager quanLy) {

        System.out.println(
                "\n===== DA HINH: THONG TIN CAC SACH ====="
        );

        if (quanLy.getDanhSach().isEmpty()) {
            System.out.println("Danh sach sach rong!");
            return;
        }

        for (Book b : quanLy.getDanhSach()) {
            System.out.println("Ma sach: " + b.getMaSach());
            System.out.println("Ten sach: " + b.getTenSach());

            System.out.printf(
                    "Gia ban: %.0f%n",
                    b.tinhGiaBan()
            );

            System.out.println("Mo ta: " + b.moTa());

            if (b instanceof Promotable) {
                Promotable p = (Promotable) b;
                p.inGiaKhuyenMai();
            }

            System.out.println(
                    "-----------------------------------"
            );
        }
    }

    // Thong ke khuyen mai va doanh thu
    public static void thongKeKhuyenMaiVaDoanhThu(
            BookManager quanLy) {

        System.out.println(
                "\n===== THONG KE KHUYEN MAI VA DOANH THU ====="
        );

        int soSachKhuyenMai = 0;
        double tongDoanhThu = 0.0;
        double doanhThuSauKhuyenMai = 0.0;

        for (Book b : quanLy.getDanhSach()) {
            double giaBan = b.tinhGiaBan();

            tongDoanhThu += giaBan * b.getSoLuong();

            if (b instanceof Promotable) {
                soSachKhuyenMai++;

                Promotable p = (Promotable) b;

                doanhThuSauKhuyenMai +=
                        p.apDungKhuyenMai(
                                PHAN_TRAM_KHUYEN_MAI
                        ) * b.getSoLuong();

            } else {
                doanhThuSauKhuyenMai +=
                        giaBan * b.getSoLuong();
            }
        }

        System.out.println(
                "So sach trien khai Promotable: "
                        + soSachKhuyenMai
        );

        System.out.printf(
                "Tong doanh thu du kien (gia goc): %.0f VND%n",
                tongDoanhThu
        );

        System.out.printf(
                "Doanh thu sau khuyen mai: %.0f VND%n",
                doanhThuSauKhuyenMai
        );
    }

    // Kiem thu cac truong hop ngoai le
    public static void kiemThuNgoaiLe(
            BookManager quanLy) {

        System.out.println(
                "\n===== KIEM THU NGOAI LE ====="
        );

        // Kiem tra them sach null
        System.out.println("\n1. Kiem tra sach null:");

        try {
            quanLy.themSach(null);

        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        // Kiem tra ma sach trung
        System.out.println("\n2. Kiem tra ma sach trung:");

        Book sachTrung = new Novel(
                "S002", "Sach thu nghiem trung ma",
                40000, 10, "Tac gia thu nghiem", 2025
        );

        try {
            quanLy.themSach(sachTrung);

        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        // Kiem tra gia am
        System.out.println("\n3. Kiem tra gia nhap am:");

        Book sachThu = new TextBook(
                "TEST01", "Sach kiem thu",
                10000, 1, "Kiem thu", 100
        );

        try {
            sachThu.setGiaNhap(-50000);

        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        // Kiem tra so luong am
        System.out.println("\n4. Kiem tra so luong am:");

        try {
            sachThu.setSoLuong(-10);

        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        // Kiem tra ma sach rong
        System.out.println("\n5. Kiem tra ma sach rong:");

        Book sachLoi = new Novel(
                "", "Sach thu nghiem ma rong",
                50000, 10, "Tac gia thu nghiem", 2025
        );

        try {
            quanLy.themSach(sachLoi);

        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        System.out.println(
                "\nHoan tat kiem thu. Danh sach sach that duoc giu nguyen."
        );
    }
}